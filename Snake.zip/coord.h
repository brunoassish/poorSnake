#pragma once

class Coord
{ public:
    unsigned short int x, y;
};
