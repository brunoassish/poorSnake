#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <windows.h>

#include "entity.h"
#include "screen.h"
#include "direction.h"
#include "coord.h"
//#include "snake_.h"
#include "food.h"
#include "game.h"

int main()
{
    srand(time(NULL));
    Game G;
    return 0;
}
